package com.fakenewsdetector.Service;

import com.fakenewsdetector.Model.News;
import com.fakenewsdetector.Repository.NewsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;


@Service
public class NewsService {
    @Autowired
    private MLIntegrationService mlIntegrationService;
    @Autowired
    private NewsRepository newsRepository;

    public News saveNews(News news) {
        news.setFake(mlIntegrationService.isFakeNews(news.getContent()));
        return newsRepository.save(news);
    }
}
