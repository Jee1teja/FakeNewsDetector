package com.fakenewsdetector.Service;

import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.util.HashMap;
import java.util.Map;

@Service
public class MLIntegrationService {

    private static final String ML_API_URL = "http://localhost:5000/predict";

    public boolean isFakeNews(String content) {
        RestTemplate restTemplate = new RestTemplate();
        Map<String, String> requestBody = new HashMap<>();
        requestBody.put("content", content);
        HttpEntity<Map<String, String>> request = new HttpEntity<>(requestBody);

        ResponseEntity<Map> response = restTemplate.postForEntity(ML_API_URL, request, Map.class);
        return (Boolean) response.getBody().get("isFake");
    }
}