from flask import Flask, request, jsonify
import joblib

app = Flask(__name__)

# Load trained model and vectorizer
model = joblib.load("fake_news_model.pkl")
vectorizer = joblib.load("vectorizer.pkl")

@app.route('/predict', methods=['POST'])
def predict():
    data = request.json
    content = data['content']
    vectorized = vectorizer.transform([content])
    prediction = model.predict(vectorized)[0]
    return jsonify({"isFake": bool(prediction)})

if __name__ == '__main__':
    app.run(port=5000)
